const mongoose = require('mongoose');
const { UserProfile } = require('./models/User');
const { Reservation } = require('./models/Reservation');

const connectDB = async () => {
  try {
    await mongoose.connect('mongodb://localhost/ReserveALabDB', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ MongoDB connected for testing');
  } catch (error) {
    console.error('❌ MongoDB connection failed:', error.message);
    process.exit(1);
  }
};

const testReservationFlow = async () => {
  try {
    console.log('\n🧪 Testing Reservation Flow...\n');

    // 1. Find a test user
    const user = await UserProfile.findOne({ user_type: 'student' });
    if (!user) {
      console.log('❌ No test user found. Please run seed script first.');
      return;
    }
    console.log(`👤 Test user: ${user.name.first} ${user.name.last} (${user.email})`);

    // 2. Check current state
    console.log(`📊 Current reservations in user array: ${user.current_reservations.length}`);
    
    const dbReservations = await Reservation.find({ user_id: user._id, status: 'active' });
    console.log(`📊 Current reservations in database: ${dbReservations.length}`);

    // 3. Create a test reservation
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const testReservation = new Reservation({
      user_id: user._id,
      laboratory: 'G301',
      reservation_date: tomorrow,
      time_slot: '09:00',
      end_time: '09:30',
      seat_number: 1,
      purpose: 'Test reservation',
      description: 'Testing reservation flow',
      is_anonymous: false,
      status: 'active'
    });

    await testReservation.save();
    console.log(`✅ Test reservation created: ${testReservation._id}`);

    // 4. Update user's current_reservations array
    if (!user.current_reservations) {
      user.current_reservations = [];
    }
    user.current_reservations.push(testReservation._id);
    await user.save();
    console.log(`✅ User's current_reservations updated`);

    // 5. Verify the changes
    const updatedUser = await UserProfile.findById(user._id);
    const updatedDbReservations = await Reservation.find({ user_id: user._id, status: 'active' });
    
    console.log(`\n📊 After test reservation:`);
    console.log(`   User array: ${updatedUser.current_reservations.length} reservations`);
    console.log(`   Database: ${updatedDbReservations.length} reservations`);
    
    // 6. Check if they match
    const userArrayIds = updatedUser.current_reservations.map(id => id.toString());
    const dbIds = updatedDbReservations.map(r => r._id.toString());
    
    console.log(`\n🔍 Verification:`);
    console.log(`   User array IDs: ${userArrayIds.join(', ')}`);
    console.log(`   Database IDs: ${dbIds.join(', ')}`);
    
    const match = userArrayIds.length === dbIds.length && 
                  userArrayIds.every(id => dbIds.includes(id));
    
    if (match) {
      console.log(`✅ SUCCESS: User array and database are in sync!`);
    } else {
      console.log(`❌ ERROR: User array and database are out of sync!`);
      
      // Find mismatches
      const missingInDb = userArrayIds.filter(id => !dbIds.includes(id));
      const missingInUser = dbIds.filter(id => !userArrayIds.includes(id));
      
      if (missingInDb.length > 0) {
        console.log(`   Missing in database: ${missingInDb.join(', ')}`);
      }
      if (missingInUser.length > 0) {
        console.log(`   Missing in user array: ${missingInUser.join(', ')}`);
      }
    }

    // 7. Test dashboard data retrieval
    console.log(`\n📋 Testing dashboard data retrieval...`);
    const dashboardReservations = await Reservation.find({ 
      user_id: user._id, 
      status: 'active' 
    }).sort({ reservation_date: 1, time_slot: 1 });
    
    console.log(`   Dashboard would show: ${dashboardReservations.length} reservations`);
    dashboardReservations.forEach((res, index) => {
      console.log(`   ${index + 1}. ${res.laboratory} | ${res.reservation_date.toDateString()} | ${res.time_slot} | Seat ${res.seat_number}`);
    });

    // 8. Clean up test reservation
    await Reservation.findByIdAndDelete(testReservation._id);
    updatedUser.current_reservations = updatedUser.current_reservations.filter(
      id => id.toString() !== testReservation._id.toString()
    );
    await updatedUser.save();
    console.log(`\n🧹 Cleaned up test reservation`);

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
};

// Run the test
connectDB().then(testReservationFlow); 