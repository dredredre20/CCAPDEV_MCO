const mongoose = require('mongoose');
const { UserProfile } = require('./models/User');
const { Reservation } = require('./models/Reservation');
const { ReservationSlot } = require('./models/ReservationSlot');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/lab_reservation_system', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

async function testReservationLogic() {
  try {
    console.log('🧪 Testing Reservation Logic...\n');

    // Test 1: Create a student reservation
    console.log('1. Testing Student Reservation Creation...');
    
    // Find or create a test student
    let student = await UserProfile.findOne({ user_type: 'student' });
    if (!student) {
      console.log('No student found, creating test student...');
      student = new UserProfile({
        name: { first: 'Test', last: 'Student' },
        email: 'test.student@example.com',
        password: 'password123',
        user_type: 'student',
        current_reservations: []
      });
      await student.save();
    }

    // Test reservation data
    const reservationData = {
      laboratory: 'G301',
      reservation_date: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
      time_slot: '10:00',
      seat_number: 1,
      purpose: 'Testing reservation logic'
    };

    // Create reservation
    const reservation = new Reservation({
      user_id: student._id,
      ...reservationData,
      end_time: '10:30',
      is_anonymous: false,
      status: 'active'
    });

    await reservation.save();

    // Create or update ReservationSlot
    let slot = await ReservationSlot.findOne({
      laboratory: reservationData.laboratory,
      date: reservationData.reservation_date,
      time_slot: reservationData.time_slot,
      seat_number: reservationData.seat_number
    });

    if (!slot) {
      slot = new ReservationSlot({
        laboratory: reservationData.laboratory,
        date: reservationData.reservation_date,
        time_slot: reservationData.time_slot,
        seat_number: reservationData.seat_number,
        is_available: false,
        is_blocked: false,
        reserved_by: student._id,
        reservation_id: reservation._id
      });
    } else {
      slot.is_available = false;
      slot.reserved_by = student._id;
      slot.reservation_id = reservation._id;
    }

    await slot.save();

    // Update student's current_reservations
    if (!student.current_reservations) {
      student.current_reservations = [];
    }
    student.current_reservations.push(reservation._id);
    await student.save();

    console.log('✅ Student reservation created successfully');
    console.log(`   - Reservation ID: ${reservation._id}`);
    console.log(`   - Slot ID: ${slot._id}`);
    console.log(`   - Student has ${student.current_reservations.length} reservations\n`);

    // Test 2: Test slot availability
    console.log('2. Testing Slot Availability...');
    
    const availableSlots = await ReservationSlot.find({
      laboratory: 'G301',
      date: reservationData.reservation_date,
      time_slot: '10:00',
      is_available: true
    });

    console.log(`   - Available slots for G301 at 10:00: ${availableSlots.length}`);
    
    const reservedSlots = await ReservationSlot.find({
      laboratory: 'G301',
      date: reservationData.reservation_date,
      time_slot: '10:00',
      is_available: false
    });

    console.log(`   - Reserved slots for G301 at 10:00: ${reservedSlots.length}\n`);

    // Test 3: Test technician blocking a slot
    console.log('3. Testing Technician Slot Blocking...');
    
    // Find or create a test technician
    let technician = await UserProfile.findOne({ user_type: 'technician' });
    if (!technician) {
      console.log('No technician found, creating test technician...');
      technician = new UserProfile({
        name: { first: 'Test', last: 'Technician' },
        email: 'test.technician@example.com',
        password: 'password123',
        user_type: 'technician',
        current_reservations: []
      });
      await technician.save();
    }

    // Block seat 2
    const blockedSlot = new ReservationSlot({
      laboratory: 'G301',
      date: reservationData.reservation_date,
      time_slot: '10:00',
      seat_number: 2,
      is_available: false,
      is_blocked: true,
      blocked_by: technician._id,
      block_reason: 'Maintenance'
    });

    await blockedSlot.save();
    console.log('✅ Slot blocked successfully');
    console.log(`   - Blocked slot ID: ${blockedSlot._id}\n`);

    // Test 4: Test view availability logic
    console.log('4. Testing View Availability Logic...');
    
    const start = new Date(reservationData.reservation_date);
    const end = new Date(reservationData.reservation_date);
    start.setHours(0, 0, 0, 0);
    end.setHours(23, 59, 59, 999);

    const reservations = await Reservation.find({
      laboratory: 'G301',
      reservation_date: { $gte: start, $lte: end },
      status: 'active'
    }).populate('user_id', 'name email');

    const blockedSlots = await ReservationSlot.find({
      laboratory: 'G301',
      date: { $gte: start, $lte: end },
      is_blocked: true
    });

    console.log(`   - Active reservations: ${reservations.length}`);
    console.log(`   - Blocked slots: ${blockedSlots.length}`);

    // Generate seat map
    const seatStatus = {};
    
    reservations.forEach(reservation => {
      seatStatus[reservation.seat_number] = {
        reserved: true,
        blocked: false,
        name: reservation.is_anonymous ? 'Anonymous' : 
              (reservation.user_id ? `${reservation.user_id.name.first} ${reservation.user_id.name.last}` : 'Unknown'),
        anonymous: reservation.is_anonymous,
        time_slot: reservation.time_slot
      };
    });

    blockedSlots.forEach(slot => {
      if (!seatStatus[slot.seat_number]) {
        seatStatus[slot.seat_number] = {
          reserved: false,
          blocked: true,
          name: 'Blocked',
          anonymous: false,
          time_slot: slot.time_slot,
          block_reason: slot.block_reason
        };
      }
    });

    console.log('   - Seat status:');
    for (let seat = 1; seat <= 5; seat++) {
      const status = seatStatus[seat];
      if (status) {
        if (status.reserved) {
          console.log(`     Seat ${seat}: Reserved by ${status.name}`);
        } else if (status.blocked) {
          console.log(`     Seat ${seat}: Blocked (${status.block_reason})`);
        }
      } else {
        console.log(`     Seat ${seat}: Available`);
      }
    }

    console.log('\n✅ All tests completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await mongoose.disconnect();
    console.log('\n🔌 Disconnected from MongoDB');
  }
}

// Run the test
testReservationLogic(); 